create
    definer = root@localhost procedure DeletePasswordResetToken(IN TokenId int)
BEGIN
    -- Kiểm tra xem token có tồn tại không trước khi xoá
    IF EXISTS (SELECT 1 FROM PasswordResetToken WHERE id = TokenId) THEN
        -- Xoá token
        DELETE FROM PasswordResetToken WHERE id = TokenId;
        
        -- In ra thông báo thành công nếu cần
        SELECT CONCAT('Password reset token with ID ', CAST(TokenId AS CHAR), ' has been deleted successfully.') AS Message;
    ELSE
        -- In ra thông báo nếu không tìm thấy token
        SELECT CONCAT('Password reset token with ID ', CAST(TokenId AS CHAR), ' does not exist.') AS Message;
    END IF;
END;

