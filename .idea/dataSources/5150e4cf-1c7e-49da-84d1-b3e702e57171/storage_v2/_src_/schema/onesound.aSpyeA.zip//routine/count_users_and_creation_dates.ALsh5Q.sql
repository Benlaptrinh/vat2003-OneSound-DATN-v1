create
    definer = root@localhost procedure count_users_and_creation_dates(IN p_day int, IN p_month int, IN p_year int)
BEGIN
    DECLARE total_users INT;
    
    SELECT *
    FROM accounts
    WHERE (p_day IS NULL OR DAY(created_date) = p_day)
        AND (p_month IS NULL OR MONTH(created_date) = p_month)
        AND (p_year IS NULL OR YEAR(created_date) = p_year);
END;

