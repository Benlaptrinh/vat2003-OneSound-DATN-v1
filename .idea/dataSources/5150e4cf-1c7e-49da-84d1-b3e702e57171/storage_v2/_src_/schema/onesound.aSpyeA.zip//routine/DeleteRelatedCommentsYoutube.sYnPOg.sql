create
    definer = root@localhost procedure DeleteRelatedCommentsYoutube(IN commentId bigint)
BEGIN
    DECLARE done INT DEFAULT FALSE;
    DECLARE deletedCommentId BIGINT;
    
    DECLARE cur CURSOR FOR
    SELECT id FROM comment_youtube WHERE id = commentId;
    
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;

    OPEN cur;
    read_loop: LOOP
        FETCH cur INTO deletedCommentId;
        IF done THEN
            LEAVE read_loop;
        END IF;
        DELETE FROM comment_youtube WHERE id = deletedCommentId;
    END LOOP;
    CLOSE cur;
END;

