create
    definer = root@localhost procedure DeletePlaylistAndSongsalong(IN playlistId bigint)
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Error occurred during deletion.';
    END;

    START TRANSACTION;

    DELETE FROM playlist_song WHERE playlist_id = playlistId;
    DELETE FROM playlist_youtube WHERE playlist_id = playlistId;
    DELETE FROM playlists WHERE id = playlistId;

    COMMIT;
END;

