

CREATE PROCEDURE [dbo].[count_users_and_creation_dates]
    @p_day INT = NULL,
    @p_month INT = NULL,
    @p_year INT = NULL
AS
BEGIN
    DECLARE @total_users INT;
    SELECT *
    FROM accounts
    WHERE (@p_day IS NULL OR DAY(created_date) = @p_day)
        AND (@p_month IS NULL OR MONTH(created_date) = @p_month)
        AND (@p_year IS NULL OR YEAR(created_date) = @p_year);
END
go

