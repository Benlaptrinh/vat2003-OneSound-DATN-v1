
CREATE PROCEDURE [dbo].[DeleteRelatedComments11]
    @commentId bigint
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @DeletedComments TABLE (id bigint); 

    INSERT INTO @DeletedComments (id)
    SELECT @commentId;

    WITH DeletedComments AS (
        SELECT id, rep_comment_id
        FROM comment_song
        WHERE id = @commentId

        UNION ALL

        SELECT cs.id, cs.rep_comment_id
        FROM comment_song cs
        JOIN DeletedComments dc ON dc.id = cs.rep_comment_id
    )
    DELETE FROM comment_song
    WHERE id IN (SELECT id FROM DeletedComments);

END;
go

