CREATE PROCEDURE [dbo].[DeleteRelatedCommentsYoutube]
@commentId bigint
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @DeletedComments TABLE (id bigint);

    INSERT INTO @DeletedComments (id)
    SELECT @commentId;

    WITH DeletedComments AS (
        SELECT id, rep_comment_id
        FROM comment_youtube
        WHERE id = @commentId

        UNION ALL

        SELECT cy.id, cy.rep_comment_id
        FROM comment_youtube cy
                 JOIN DeletedComments dc ON dc.id = cy.rep_comment_id
    )
    DELETE FROM comment_youtube
    WHERE id IN (SELECT id FROM DeletedComments);

END;
go

