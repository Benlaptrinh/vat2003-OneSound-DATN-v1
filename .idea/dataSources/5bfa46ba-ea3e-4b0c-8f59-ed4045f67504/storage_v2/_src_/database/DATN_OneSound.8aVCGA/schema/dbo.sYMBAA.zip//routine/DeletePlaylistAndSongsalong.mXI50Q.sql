CREATE PROCEDURE DeletePlaylistAndSongsalong
    @playlistId BIGINT
AS
BEGIN
    SET NOCOUNT ON;

    BEGIN TRY
        -- Bắt đầu giao dịch
        BEGIN TRANSACTION;

        -- Xóa dữ liệu từ bảng [dbo].[playlist_song] dựa trên playlist_id
        DELETE FROM [dbo].[playlist_song]
        WHERE [playlist_id] = @playlistId;

		 DELETE FROM [dbo].[playlist_youtube]
		 WHERE [playlist_id] = @playlistId;

        -- Xóa playlist từ bảng [dbo].[playlists]
        DELETE FROM [dbo].[playlists]
        WHERE id = @playlistId;

        -- Commit giao dịch nếu mọi thứ diễn ra suôn sẻ
        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        -- Rollback nếu có lỗi xảy ra
        ROLLBACK TRANSACTION;

        -- Phát ra lỗi
        THROW;
    END CATCH;
END;

go

