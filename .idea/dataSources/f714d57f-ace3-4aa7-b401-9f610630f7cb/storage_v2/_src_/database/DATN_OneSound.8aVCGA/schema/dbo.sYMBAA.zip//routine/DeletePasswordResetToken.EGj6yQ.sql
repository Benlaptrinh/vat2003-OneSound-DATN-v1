CREATE PROCEDURE DeletePasswordResetToken
@TokenId INT
AS
BEGIN
    -- Kiểm tra xem token có tồn tại không trước khi xoá
    IF EXISTS (SELECT 1 FROM PasswordResetToken WHERE id = @TokenId)
        BEGIN
            -- Xoá token
            DELETE FROM PasswordResetToken WHERE id = @TokenId;

            -- In ra thông báo thành công nếu cần
            PRINT 'Password reset token with ID ' + CAST(@TokenId AS VARCHAR) + ' has been deleted successfully.';
        END
    ELSE
        BEGIN
            -- In ra thông báo nếu không tìm thấy token
            PRINT 'Password reset token with ID ' + CAST(@TokenId AS VARCHAR) + ' does not exist.';
        END
END
go

